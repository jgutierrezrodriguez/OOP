#include "Espada.h"

Espada::Espada(const Espada& orig) {
}

Espada::~Espada() {
}

std::string Espada::getDescripcion() const {
    return "Espada";
}