#include "Filete.h"

Filete::Filete(const Filete& orig) {
}

Filete::~Filete() {
}

std::string Filete::getDescripcion() const {
    return "Filete";
}